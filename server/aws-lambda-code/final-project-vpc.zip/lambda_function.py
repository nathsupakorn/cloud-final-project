import json
import base64
import boto3


def predict_posture(image):
    
    return json.dumps({
        "statusCode": 200,
        "body": "predict-posture"
    })


def lambda_handler(event, context):
    # TODO implement
    method = event["requestContext"]["http"]["method"]
    path =  event["requestContext"]["http"]["path"]
    

    if method == "POST" and path == "/default/predict-posture":
        body = json.loads(event["body"])
        return predict_posture(base64.b64decode(body['image']))
    else:
        return 400
    